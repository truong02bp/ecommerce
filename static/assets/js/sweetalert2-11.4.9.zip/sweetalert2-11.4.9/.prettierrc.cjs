module.exports = {
  ...require('@sweetalert2/prettier-config'),
}
